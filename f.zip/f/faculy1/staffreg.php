<?php
include("include\dbconnection.php");
if(isset($_POST['submit']))
{
$v1=$_POST['name'];
$v2=$_POST['quali'];
$v3=$_POST['addrr'];
$v4=$_POST['design'];
$v5=$_POST['doj'];
$v6=$_POST['experi'];
$v7=$_POST['email'];
$v8=$_POST['mob'];
$v9=$_POST['username'];
$v10=$_POST['pwd1'];

$sql=mysql_query("insert into staff_registration values (id,'$v1','$v2','$v3','$v4','$v5','$v6','$v7','$v8','$v9','$v10','staff')");
if(!$sql)
{    $res1= "<font style='font-family:Verdana; font-size:12px; font-weight:bold; color:#FF0000;'>Record not inserted<h2>".mysql_error()."</h2></font>";
echo $res1;}
else {  $res1= "<font style='font-family:Verdana; font-size:12px; font-weight:bold; color:#FF0000;'>Record inserted successfully</font>";
		echo $res1;}
}
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Faculty Management</title>
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-responsive.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/main.css">
    <script src="js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    <link rel="shortcut icon" href="images/favicon.png">
<script>
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57))
	{
        return false;
    }
    return true;
}
</script>
<script type="text/javascript">

  function checkForm(form)
  {
    if(form.username.value == "") {
      alert("Error: Username cannot be blank!");
      form.username.focus();
      return false;
    }
    re = /^\w+$/;
    if(!re.test(form.username.value)) {
      alert("Error: Username must contain only letters, numbers and underscores!");
      form.username.focus();
      return false;
    }

    if(form.pwd1.value != "" && form.pwd1.value == form.pwd2.value) {
      if(form.pwd1.value.length < 6) {
        alert("Error: Password must contain at least six characters!");
        form.pwd1.focus();
        return false;
      }
      if(form.pwd1.value == form.username.value) {
        alert("Error: Password must be different from Username!");
        form.pwd1.focus();
        return false;
      }
      re = /[0-9]/;
      if(!re.test(form.pwd1.value)) {
        alert("Error: password must contain at least one number (0-9)!");
        form.pwd1.focus();
        return false;
      }
      re = /[a-z]/;
      if(!re.test(form.pwd1.value)) {
        alert("Error: password must contain at least one lowercase letter (a-z)!");
        form.pwd1.focus();
        return false;
      }
      re = /[A-Z]/;
      if(!re.test(form.pwd1.value)) {
        alert("Error: password must contain at least one uppercase letter (A-Z)!");
        form.pwd1.focus();
        return false;
      }
    } else {
      alert("Error: Please check that you've entered and confirmed your password!");
      form.pwd1.focus();
      return false;
    }

    alert("You entered a valid password: " + form.pwd1.value);
    return true;
  }

</script>
	</head>

<body>
    <!--Header-->
    <header class="navbar navbar-fixed-top">
        <div class="navbar-inner">
            <div class="container">
                <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
                <a id="logo" class="pull-left" href="index.php"></a>
                <div class="nav-collapse collapse pull-right">
                    <ul class="nav">
                        <li><a href="index1.php">Home</a></li>
                                <li class="active"> <a href="facultyreg.php">Registration</a></li>
                            				 
						 <li> <a href="login.php">Login</a>
                    </ul>        
                </div>
            </div>
        </div>
    </header>
    <!-- /header -->
	 <section class="title">
        <div class="container">
            <div class="row-fluid">
                <div class="span6">
                    <h1>Registration</h1>
                </div>
                <div class="span6">
                    <ul class="breadcrumb pull-right">
                        <li><a href="index1.php">Home</a> <span class="divider">/</span></li>
                        <li class="active">Faculty</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
	
	
    <section id="contact-page" class="container">
        <div class="row-fluid">
                <center> <h2>Faculty Registration</h2></center>
                <div class="status alert alert-success" style="display: none"></div>
                <form method="post" onsubmit="return checkForm(this);">
                    <div class="row-fluid">
                       
					<center><input placeholder="Name" name="name" type="text" required=""/> </br>
					<input  placeholder="Qualificaion" name="quali" type="text" required=""/> </br>
					<textarea placeholder="Address" rows="4" cols="50"  name="addrr" required=""></textarea> </br>
					<input  placeholder="Designation" name="design" type="text" required=""/> </br>
					<label> Date of join </label> <input  placeholder="Date of join" name="doj" type="date" required=""/> </br>
					<input  placeholder="Experience" name="experi" type="text" required=""/> </br> 
					<input  placeholder="Email Id" name="email" type="email" required=""/> </br> 
					<input  placeholder="Mobile No" name="mob" type="text" onkeypress="return isNumber(event)" maxlength="10" required=""/> </br>
					<input  placeholder="Login UserName" name="username" type="text" required=""/> </br>
					<input  placeholder="Password" name="pwd1" type="password" required=""/> </br>
					<input  placeholder="Re-enter Password" name="pwd2" type="password" required=""/> </br>					</center>
                    </div>
                   <center> <input type="submit" name="submit" class="btn btn-primary btn-large"  value="Submit"></center> 
                </form>
            </div>
    </section>
</body>
</html>
