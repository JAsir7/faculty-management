<?php
	include("include\dbconnection.php");
	$id=$_GET['jid'];
$fname = $_POST['fname'];
$tpaper = $_POST['tpaper'];
$njourn = $_POST['njourn'];
$pno = $_POST['pno'];
$volu = $_POST['volu'];
$issno = $_POST['issno'];
$date = $_POST['date'];	
	$str = "update jour SET fname='$fname', tpaper='$tpaper' ,njourn='$njourn',pno='$pno',volu='$volu',issno='$issno',date='$date' WHERE jid='$id'";
$str1=mysql_query($str);
header('location:reports.php');
	?>


