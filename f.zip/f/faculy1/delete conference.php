<?php
include("include\dbconnection.php");

if (isset($_GET['cid']) && is_numeric($_GET['cid']))
{
$jid = $_GET['cid'];

$result = mysql_query("DELETE FROM conference WHERE cid='$cid'")
or die(mysql_error());

header("Location: reports.php");
}
else

{
header("Location: reports.php");
}
?>