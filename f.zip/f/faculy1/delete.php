<?php
include("include\dbconnection.php");

if (isset($_GET['jid']) && is_numeric($_GET['jid']))
{
$jid = $_GET['jid'];

$result = mysql_query("DELETE FROM jour WHERE jid='$jid'")
or die(mysql_error());

header("Location: reports.php");
}
else

{
header("Location: reports.php");
}
?>