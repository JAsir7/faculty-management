<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Faculty Management</title>
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-responsive.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/sl-slide.css">
    <script src="js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    <link rel="shortcut icon" href="images/favicon.png">
	<script>
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57))
	{
        return false;
    }
    return true;
}
</script>
</head>

<body>
    <!--Header-->
    <header class="navbar navbar-fixed-top">
        <div class="navbar-inner">
            <div class="container">
                <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
                <a id="logo" class="pull-left"></a>
                <div class="nav-collapse collapse pull-right">
				<?php 
                       session_start();
                                    $nam=$_SESSION['username']; 
                     echo "<h4 style=text-align:left;margin-left:350px;color:#399F0D;> Welcome: $nam </h4>";
                       ?>
                    <ul class="nav">
                        <li><a href="home.php">Home</a></li>
                        <li > <a href="workshop.php">Workshop</a>
						 </li>           
							<li class="dropdown" >
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Publications <i class="icon-angle-down"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="journal.php">Journal</a></li>
                                <li><a href="conference.php">Conference</a></li>
                            </ul> </li>		
							<li > <a href="faculty_leave.php">Faculty Leave</a>
						 <li class="active"> <a href="reports.php">Reports</a>		</li>					
						 <li> <a href="logout.php">Logout</a> </li>
                    </ul>        
                </div>
            </div>
        </div>
    </header>
    <!-- /header -->
	 <section class="title">
        <div class="container">
            <div class="row-fluid">
                <div class="span6">
                    <h1>Reports</h1>
                </div>
                <div class="span6">
                    <ul class="breadcrumb pull-right">
                        <li><a href="home.php">Home</a> <span class="divider">/</span></li>
                        <li class="active">Reports</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
	
	
    <section id="contact-page" class="container">
        <div class="row-fluid">
                <center> <h2>Workshop</h2></center>
                <div class="status alert alert-success" style="display: none"></div>
                <form method="post" action="worreport.php">
                    <div class="row-fluid">
			</div>
			<div class="sub-main-w3">	
		<center>
					<input  placeholder="Search by Year" name="sdate" type="text" onkeypress="return isNumber(event)" maxlength="4" required=""> </br> </center>
                    </div>
                   <center> <button type="submit" class="btn btn-primary btn-large">Submit</button></center> 
                </form>
            </div>
    </section>
	 
    <script src="js/vendor/jquery-1.9.1.min.js"></script>
    <script src="js/vendor/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    

</body>
</html>
