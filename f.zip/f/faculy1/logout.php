<?php
session_start();
unset($_SESSION["username"]);
unset($_SESSION["password"]);
echo 'Successfully Logged Out.';
header('Refresh: 1; URL = "http://localhost:80/f/faculy1/login.php');
?>