<?php
include("include\dbconnection.php");
if(isset($_POST['submit']))
{
$v1=$_POST['fname'];
$v2=$_POST['title'];
$v3=$_POST['organizedby'];
$v4=$_POST['sdate'];
$v5=$_POST['edate'];

$sql=mysql_query("insert into workshop values (wid,'$v1','$v2','$v3','$v4','$v5')");
if(!$sql)
{    $res1= "<font style='font-family:Verdana; font-size:12px; font-weight:bold; color:#FF0000;'>Record not inserted<h2>".mysql_error()."</h2></font>";
echo $res1;}
else {  $res1= " </br> <font style='font-family:Verdana; font-size:12px; font-weight:bold; color:#FF0000;'>Record inserted successfully</font>";
		echo $res1;}
}
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Faculty Management</title>
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-responsive.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/main.css">
    <script src="js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    <link rel="shortcut icon" href="images/favicon.png">
</head>

<body>
    <!--Header-->
    <header class="navbar navbar-fixed-top">
        <div class="navbar-inner">
            <div class="container">
                <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
                <a id="logo" class="pull-left"></a>
                <div class="nav-collapse collapse pull-right">
				<?php 
                       session_start();
                                    $nam=$_SESSION['username']; 
                     echo "<h4 style=text-align:left;margin-left:350px;color:#399F0D;> Welcome: $nam </h4>";
                       ?>
                    <ul class="nav">
                        <li><a href="home.php">Home</a></li>
                        <li class="active"> <a href="workshop.php">Workshop</a>
						 </li>           

							<li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Publications <i class="icon-angle-down"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="journal.php">Journal</a></li>
                                <li><a href="conference.php">Conference</a></li>
                            </ul> </li>		
							<li > <a href="faculty_leave.php">Faculty Leave</a>
						 <li> <a href="reports.php">Reports</a> </li>					
						 <li> <a href="logout.php">Logout</a> </li>
                    </ul>        
                </div>
            </div>
        </div>
    </header>
    <!-- /header -->
	 <section class="title">
        <div class="container">
            <div class="row-fluid">
                <div class="span6">
                    <h1>Workshop</h1>
                </div>
                <div class="span6">
                    <ul class="breadcrumb pull-right">
                        <li><a href="home.php">Home</a> <span class="divider">/</span></li>
                        <li class="active">Workshop</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
	
	
    <section id="contact-page" class="container">
        <div class="row-fluid">
                <center> <h2>Workshop Details</h2></center>
                <div class="status alert alert-success" style="display: none"></div>
                <form method="post" action="workshop.php">
                    <div class="row-fluid">
                       
					<center><input placeholder="Faculty Name" name="fname" type="text" required=""/> </br>
					<input  placeholder="Title" name="title" type="text" required=""/> </br>
					<input  placeholder="Organized By" name="organizedby" type="text" required=""/> </br>
					<label> <b> Start Date </b> </label> <input  placeholder="Date" name="sdate" type="date" required=""/> </br> 
					<label> <b> End Date </b></label><input  placeholder="Date" name="edate" type="date" required=""/> </br></center>
                    </div>
                   <center> <input type="submit" name="submit" class="btn btn-primary btn-large"  value="Submit"></center> 
                </form>
            </div>
    </section>
	
	
    <script src="js/vendor/jquery-1.9.1.min.js"></script>
    <script src="js/vendor/bootstrap.min.js"></script>
    <script src="js/main.js"></script>

</body>
</html>
