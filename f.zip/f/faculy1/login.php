<?php
include("include\dbconnection.php");
session_start();
if(isset($_POST['submit']))
{
$sql = "SELECT * FROM facreg WHERE username='".mysql_escape_string($_POST['username'])."' and pwd1='".mysql_escape_string($_POST['password'])."'";
$result = mysql_query($sql,$link);
		if (@mysql_num_rows($result)!=0)
		{
			$row = @mysql_fetch_array($result);
			$_SESSION['username']=$row['username'];
			       if($row['utype']=="admin")
					{
					header('LOCATION:Admin-Home.php');
					exit();
					}
					else if($row['utype']=="faculty")
					{
				    header("LOCATION:home.php");

					exit();
					}					
		}
		else if(@mysql_num_rows($result)==0)
		            {
			             $msg = "<font style='font-family:Verdana; font-size:12px; font-weight:bold; color:#FF0000;'>Invalid UserName or Password</font><br><br>"; 
		            }
}
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Faculty Management</title>
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-responsive.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/main.css">
    <script src="js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    <link rel="shortcut icon" href="images/favicon.png">
</head>

<body>
    <!--Header-->
    <header class="navbar navbar-fixed-top">
        <div class="navbar-inner">
            <div class="container">
                <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
                <a id="logo" class="pull-left"></a>
                <div class="nav-collapse collapse pull-right">
                    <ul class="nav">
                        <li><a href="index.php">Home</a></li>
                        <li class="dropdown">

                                <li><a href="facultyreg.php">Registration</a></li>
                            
                        <li class="active"> <a href="login.php">Login</a> </li>           
                    </ul>        
                </div>
            </div>
        </div>
    </header>
    <!-- /header -->
	 <section class="title">
        <div class="container">
            <div class="row-fluid">
                <div class="span6">
                    <h1>Login</h1>
                </div>
                <div class="span6">
                    <ul class="breadcrumb pull-right">
                        <li><a href="index1.php">Home</a> <span class="divider">/</span></li>
                        <li class="active">Login</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
	
	
    <section id="contact-page" class="container">
        <div class="row-fluid">
                <center> <h2>Login</h2></center>
                <div class="status alert alert-success" style="display: none"></div>
                <form  name="form1" method="post">
                    <div class="row-fluid">
					<center><input placeholder="UserName" name="username" type="text" required=""/> </br>
					<input  placeholder="Password" name="password" type="password" required=""/> </br>
					<a href="facultyreg.php">New User</a></center>
                    </div>
                   <center> <input type="submit" name="submit" class="btn btn-primary btn-large"  value="SignIn"></center> 
				   </br>
				  <center> <span>
				   <?php
				   if(isset($_POST['submit']))
                           { 
					    if($msg!='')
						  {
					   echo $msg;
						   }
						   }
						   ?></span> </center>
						   
                </form>
            </div>
    </section>
	</body>
</html>
