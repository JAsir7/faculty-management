<?php
$dbms="mysql";
$dbhost="localhost";
$dbname="f";
$dbuser="root";
$dbpasswd="";
$link=mysql_connect($dbhost, $dbuser, $dbpasswd)
or die (mysql_error());
$status = mysql_select_db($dbname, $link) or die (mysql_error());
?>