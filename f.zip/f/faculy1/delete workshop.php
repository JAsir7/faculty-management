<?php
include("include\dbconnection.php");

if (isset($_GET['wid']) && is_numeric($_GET['wid']))
{
$jid = $_GET['wid'];

$result = mysql_query("DELETE FROM workshop WHERE wid='$wid'")
or die(mysql_error());

header("Location: reports.php");
}
else

{
header("Location: reports.php");
}
?>